var contenido=[
    {'TIPO':'GOO','TITULO':'DBDesigner4 Portable','RUTA':'./DBDesigner4.zip','NUEVO':1},
    {'TIPO':'GOO','TITULO':'MYSQL Portable','RUTA':'http://localhost/ovas/ova_PHPBasico/mini_server_11.zip','NUEVO':0},
    {'TIPO':'GOO','TITULO':'HeidiSql Win10','RUTA':'https://www.heidisql.com/installers/HeidiSQL_11.0.0.5919_Setup.exe','NUEVO':0},
    {'TIPO':'GOO','TITULO':'XAMPP Win10','RUTA':'https://www.apachefriends.org/xampp-files/7.4.9/xampp-windows-x64-7.4.9-0-VC15-installer.exe'},
    {'TIPO':'GOO','TITULO':'SQLITE TOOLS','RUTA':'https://sqlite.org/2020/sqlite-tools-win32-x86-3330000.zip'},
  {'TIPO':'GOO','TITULO':'DB BROWSER SQLITE','RUTA':'https://download.sqlitebrowser.org/SQLiteDatabaseBrowserPortable_3.12.0_English.paf.exe','NUEVO':1},
  {'TIPO':'GOO','TITULO':'VARIABLES DE SESION EN PHP','RUTA':'https://up9bp0pfq2ue4kizq9zseg-on.drv.tw/1CGMLTI/1-FORMACION/BASICO/GUIAS/PHP(BASICO)/TALLERES/LIBSESION/LIBSESION.htm','NUEVO':1},
  {'TIPO':'GOO','TITULO':'PIZARRA POO','RUTA':'https://up9bp0pfq2ue4kizq9zseg-on.drv.tw/1CGMLTI/1-FORMACION/BASICO/GUIAS/PHP(BASICO)/TALLERES/PIZPOO/PIZPOO.htm','NUEVO':1},
  {'TIPO':'GOO','TITULO':'PIZARRA INTERFACES','RUTA':'https://up9bp0pfq2ue4kizq9zseg-on.drv.tw/Ardora/PIZARRA/PIZARRA.htm','NUEVO':1},
  {'TIPO':'GOO','TITULO':'MATERIALES DE FORMACION','RUTA':'https://up9bp0pfq2ue4kizq9zseg-on.drv.tw/1CGMLTI/1-FORMACION/BASICO/GUIAS/PHP(BASICO)/TALLERES/PESTA/PESTA.htm','NUEVO':1},
  {'TIPO':'GOO','TITULO':'ESQUEMA SALUD PARA MYSQL','RUTA':'https://drive.google.com/file/d/1EY2H7-OeJ10yvxGzKbyA0c4BGIx8pbpl/view?usp=sharing','NUEVO':1},
  {'TIPO':'GOO','TITULO':'ESQUEMA SALUD PARA SQLITE','RUTA':'https://drive.google.com/file/d/1HuCn98e_MxEn0FTDQ79SxpbuZR7Fiq25/view?usp=sharing','NUEVO':1},
  {'TIPO':'GOO','TITULO':'ESQUEMA COVID19 FORMATO CSV','RUTA':'https://drive.google.com/file/d/1Uyb-aObqjupOYdZRGkV52x75ODJ3npva/view?usp=sharing','NUEVO':1},
  {'TIPO':'GOO','TITULO':'RECURSOS TALLER API-RES','RUTA':'https://github.com/fegasu/api','NUEVO':1}
];