var contenido=[
    {'TIPO':'GOO','TITULO':'TODO EL MUNDO DEBERIA SABER PROGRAMAR','RUTA':'https://www.youtube.com/watch?v=1bDK1-U1edE&t=7s'},
    {'TIPO':'GOO','TITULO':'CURSO DE PHP','RUTA':'http://www.ticarte.com/sites/su/users/7/arch/manual_php5_basico.pdf'},
    {'TIPO':'GOO','TITULO':'INTRODUCCION A LOS PATRONES DE DISEÑO','RUTA':'https://drive.google.com/file/d/1tSi6c1S_kdMv_fs5tZ8lX7V9eUJQvK5P/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'UML Y PATRONES DE DISEÑO','RUTA':'https://drive.google.com/file/d/1h45WXrqlqt_kKPbzlX-M1CEidwJo2xIF/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'PATRONES DE DISEÑO','RUTA':'https://drive.google.com/file/d/1BlxWZ88m4h0lVV4ooeX1r0_SqVBalY4q/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'PATRON DE DISEÑO ORM','RUTA':'https://programarfacil.com/blog/que-es-un-orm/','NUEVO':1},
    {'TIPO':'GOO','TITULO':'Curso PHP MySQL','RUTA':'https://www.youtube.com/watch?v=I75CUdSJifw&list=PLU8oAlHdN5BkinrODGXToK9oPAlnJxmW_'}
];