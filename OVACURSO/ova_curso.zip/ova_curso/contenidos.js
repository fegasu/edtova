var contenido=[
    {'TIPO':'GOO','TITULO':'DESARROLLO WEB CON PHP # 1','RUTA':'https://drive.google.com/file/d/1aVdV_OdCoK7C4OeesQ9lg5_slLmAB6Bf/view?usp=sharing'},
    {'TIPO':'GOO','TITULO':'DESARROLLO WEB CON PHP # 2','RUTA':'https://drive.google.com/file/d/1a2Hi56JbRrr_6nCnB46-i8X14jn8G0lb/view?usp=sharing'},
    {'TIPO':'GOO','TITULO':'DESARROLLO WEB CON PHP # 3','RUTA':'https://drive.google.com/file/d/1QvuLSOV-YhCh0YV5BwuoI0KPLXGP_Vlc/view?usp=sharing'},
    {'TIPO':'GOO','TITULO':'DESARROLLO WEB CON PHP # 4','RUTA':'https://drive.google.com/file/d/1CdwxKyzIiAXERgBlVvAiCrqAr08VRUvu/view?usp=sharing'},
    {'TIPO':'GOO','TITULO':'ARREGLOS EN PHP','RUTA':'https://drive.google.com/file/d/1-8kCrfqfOD69aHYmbw3opeo8m7itA-ZA/view?usp=sharing'},
    {'TIPO':'GOO','TITULO':'PROGRAMACION ORIENTADA A OBJETOS','RUTA':'https://diego.com.es/programacion-orientada-a-objetos-en-php'},
    {'TIPO':'GOO','TITULO':'CLASES ABSTRACTAS','RUTA':'https://drive.google.com/file/d/1iK4pegsBhoa-ff8t2_SoI9z2t20bATxj/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'INTERFASES POO','RUTA':'https://drive.google.com/file/d/1KoQCFdVOalzftyojmItwDhgA3eSPNd2c/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'CLASES GENERICAS POO','RUTA':'https://www.jose-aguilar.com/blog/clase-stdclass-php/','NUEVO':1},
    {'TIPO':'GOO','TITULO':'NAMESPACE','RUTA':'https://jairogarciarincon.com/clase/programacion-orientada-a-objetos-en-php/namespaces','NUEVO':1},
    {'TIPO':'GOO','TITULO':'PATRONES DE DISEÑO','RUTA':'https://diego.com.es/patrones-de-diseno-en-php'},
    {'TIPO':'GOO','TITULO':'PATRON DE DISEÑO DECORADOR','RUTA':'http://fcarrizalest.com/patron-de-dise%C3%B1o-decorador-decorator-pattern-en-php'},
    {'TIPO':'GOO','TITULO':'APPLYING UML AND PATTERNS','RUTA':'https://drive.google.com/file/d/1T5lO6aLkypMjjDnrS4_RAQTW-DEUgryE/view?usp=sharing'},
    {'TIPO':'GOO','TITULO':'MODELO VISTA CONTROLADOR','RUTA':'https://jairogarciarincon.com/clase/programacion-orientada-a-objetos-en-php/patron-mvc'},
    {'TIPO':'GOO','TITULO':'EL NUEVO PHP:CONCEPTOS AVANZADOS','RUTA':'https://elibro-net.bdigital.sena.edu.co/es/ereader/senavirtual/51353',"NUEVO":1}

];