var contenido=[
    {'TIPO':'GOO','TITULO':'programa de formación','RUTA':'https://drive.google.com/uc?id=1AnfDReq9G0NckyZPCyZkhauaA6N4Sl5i'},
    {'TIPO':'GOO','TITULO':'PROYECTO DE FORMACION','RUTA':'https://drive.google.com/uc?id=143V9aZV0vN_0OWmBC9pyKSVNkEWbawQa'},
    {'TIPO':'GOO','TITULO':'GUIA DE APRENDIZAJE','RUTA':'https://drive.google.com/uc?id=1NwpbkdZhVqERVavKwIt2fKmc6St-5vJl','NUEVO':1},
   {'TIPO':'WEB','TITULO':'PORTAFOLIO DE EVIDENCIAS','RUTA':'https://siomi.datasena.com/'}
];