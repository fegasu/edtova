<?php
class ejemplo1{
	public $x=5;
	private $y=10;
	protected $x=15;
}
$c=new ejemplo1();
echo $c->x."<br>";