<?php
class ejercicio1{
	public $x=25;
	private $y=35;
	protected $z=45;
}
$c1=new ejercicio1();
echo $c1->x."<br>";