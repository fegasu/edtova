var contenido=[
    {'TIPO':'GOO','TITULO':'T1. Arreglos y matrices','RUTA':'https://drive.google.com/file/d/1mlpmW4i-tlg3yDMYcmspvjQOa4noh8yb/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'T2. Formularios GET, POST y funciones','RUTA':'https://drive.google.com/file/d/16W0MGu6iCHFiH0w-oQtmGfF-z_NsI8H1/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'T3. Trabajando PHP con POO','RUTA':'https://drive.google.com/file/d/1-qRDdpcaq7hYomEh47_5I63vtFDqcc_8/view?usp=sharing','NUEVO':1},
    {'TIPO':'GOO','TITULO':'T4. Conectando con base de datos','RUTA':'https://drive.google.com/file/d/1XSexFgPc5IM2VNnhmOrzQ_dLgO0Q4vo8/view?usp=sharing','NUEVO':1},
//    {'TIPO':'GOO','TITULO':'T5. Implementando patrones de diseño con PHP','RUTA':''},
   {'TIPO':'GOO','TITULO':'T5. API REST sin framework','RUTA':'https://drive.google.com/file/d/1zXFz5q0bD7RvQditabF4dV6NuKw01BU9/view?usp=sharing','NUEVO':1}
];