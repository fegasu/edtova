var contenido=[
    {'TIPO':'GOO','TITULO':'A1. CRUCIGRAMA POO','RUTA':'https://up9bp0pfq2ue4kizq9zseg-on.drv.tw/1CGMLTI/1-FORMACION/BASICO/GUIAS/PHP(BASICO)/MATERIALES%20DE%20APOYO/CrucigramaPOO.htm'},
    {'TIPO':'GOO','TITULO':'A2. SOPA DE LETRA POO','RUTA':'https://up9bp0pfq2ue4kizq9zseg-on.drv.tw/1CGMLTI/1-FORMACION/BASICO/GUIAS/PHP(BASICO)/TALLERES/sopapop/sopapop.htm'},
    {'TIPO':'GOO','TITULO':'A3. CUESTIONARIO API-REST','RUTA':'https://up9bp0pfq2ue4kizq9zseg-on.drv.tw/ovas/ova_PHPBasico/TESTAPI.htm'}
 ];