print("Status: 302")
print("Location: /static/demos/index.html")
