var contenido=[
    {'TIPO':'GOO','TITULO':'programa de formación','RUTA':''},
    {'TIPO':'GOO','TITULO':'PROYECTO DE FORMACION','RUTA':''},
    {'TIPO':'GOO','TITULO':'GUIA DE APRENDIZAJE','RUTA':'','NUEVO':1}
];