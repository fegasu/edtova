var contenido=[
//    {'TIPO':'GOO','TITULO':'EL NUEVO PHP:CONCEPTOS AVANZADOS','RUTA':'https://elibro-net.bdigital.sena.edu.co/es/ereader/senavirtual/51353',"NUEVO":1}

];